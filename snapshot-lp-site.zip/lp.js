const menu=document.querySelector('.menu-button'),mobileNav=document.querySelector('#mobile-nav');
function closeMenu(){mobileNav.hidden=true;menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','メニューを開く');}
menu.addEventListener('click',()=>{const expanded=menu.getAttribute('aria-expanded')==='true';menu.setAttribute('aria-expanded',String(!expanded));menu.setAttribute('aria-label',expanded?'メニューを開く':'メニューを閉じる');mobileNav.hidden=expanded;});
mobileNav.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!mobileNav.hidden){closeMenu();menu.focus();}});
const viewport=document.querySelector('.demo-viewport'),frame=viewport.querySelector('iframe');
function resizeDemo(){frame.style.transform=`scale(${viewport.clientWidth/1280})`;}
new ResizeObserver(resizeDemo).observe(viewport);resizeDemo();
window.addEventListener('message',event=>{if(event.origin===location.origin&&event.source===frame.contentWindow&&event.data?.type==='snapshot-lp-ready')frame.contentWindow.postMessage({type:'snapshot-lp-view',view:'drawing'},location.origin);});
