const menu=document.querySelector('.menu-button'),mobileNav=document.querySelector('#mobile-nav');
function closeMenu(){mobileNav.hidden=true;menu.setAttribute('aria-expanded','false');menu.setAttribute('aria-label','メニューを開く');}
menu.addEventListener('click',()=>{const expanded=menu.getAttribute('aria-expanded')==='true';menu.setAttribute('aria-expanded',String(!expanded));menu.setAttribute('aria-label',expanded?'メニューを開く':'メニューを閉じる');mobileNav.hidden=expanded;});
mobileNav.querySelectorAll('a').forEach(a=>a.addEventListener('click',closeMenu));
document.addEventListener('keydown',e=>{if(e.key==='Escape'&&!mobileNav.hidden){closeMenu();menu.focus();}});

const paperDialog=document.querySelector('#paper-dialog');
const paperLargeImage=document.querySelector('#paper-large-image');
const paperTitle=document.querySelector('#paper-dialog-title');
let paperTrigger=null;
document.querySelectorAll('[data-paper]').forEach(button=>button.addEventListener('click',()=>{paperTrigger=button;paperLargeImage.src=button.dataset.paper;paperLargeImage.alt=button.dataset.paperTitle+'の実際の出力見本（サンプル）';paperTitle.textContent=button.dataset.paperTitle;paperDialog.showModal();}));
document.querySelector('#paper-close').addEventListener('click',()=>paperDialog.close());
paperDialog.addEventListener('click',event=>{if(event.target===paperDialog){const rect=paperDialog.getBoundingClientRect();if(event.clientX<rect.left||event.clientX>rect.right||event.clientY<rect.top||event.clientY>rect.bottom)paperDialog.close();}});
paperDialog.addEventListener('close',()=>paperTrigger?.focus());
